Finger hook with screw slots by SLAM-ER on Thingiverse: https://www.thingiverse.com/thing:135240

Summary:
I remixed Spooner2011's finger hook (thanks Spooner!) to fix up the manifold errors (overlapping objects) which were giving me problems slicing with KISSlicer, plus I added some wall-mountable screw slots for a sturdy way of fixing it to the wall.  See my new derivative that eliminates the base completely while still being screw mountable!